//
//  Story01.swift
//  ColorMatchGame
//
//  Created by David Goggins on 2023/04/20.
//

import SwiftUI

struct Story10: View {
    var body: some View {
        ZStack {
            Color(red: 255 / 255, green: 242 / 255, blue: 125 / 255).ignoresSafeArea()
            VStack {

                Text("What is dementia?")
                    .font(.system(size: 55, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))
//                    .offset(y: -100)
//                    .opacity(0)
                
                Image("imageSquare09")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 800, height: 800, alignment: .center)
                    .offset(y: -100)
                VStack{
                    Text("The best treatment is prevention, and dementia is no exception.")
                }
                    .frame(width: 800)
                    .lineLimit(nil) // 줄의 개수 제한 X
                    .allowsTightening(false) // 압축 X
                    .font(.system(size: 35, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))
                    .padding(15)
                    .background(Color.white)
                    .border(.white, width: 3) // border 설정 (Rectangle일 때)
                        .overlay( // 뷰를 겹치게 하여 border 설정, 라운드 처리를 할 경우 overlay를 통해 border 처리를 해주어야 한다.
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.white, lineWidth: 20)
                        )
                    .offset(y: -100)

                NavigationLink(destination: Story11()){
                    Text("NEXT")
                        .frame(width: 300, height: 100)
                        .background(Color.white)
                        .cornerRadius(50)
                    //                            .font(.largeTitle)
                        .font(.system(size: 50, weight: .semibold, design: .rounded))
                        .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))

                }// EndNavigationLink
                
            }
        }
    }
}

struct Story10_Pfdview: PreviewProvider {
    static var previews: some View {
        Story10()
    }
}


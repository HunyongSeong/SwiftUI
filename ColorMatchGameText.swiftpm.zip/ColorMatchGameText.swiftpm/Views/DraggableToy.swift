//
//  SwiftUIView.swift
//  
//
//  Created by David Goggins on 2023/04/13.
//

// 사용자가 컨트롤 하게될 하나의 공
import SwiftUI

struct DraggableToy<Draggable: Gesture>: View {
    //<Draggable: Gesture> / Protocol
    let toy: Toy
    private let size: CGFloat = 100
    let position: CGPoint
    let positionTwo: CGPoint // <<ADD ✅
    let gesture: Draggable

    var body: some View {
        HStack{
            ZStack{
//                Rectangle()
//                    .fill(toy.color)
//                    .frame(width: 500, height:  size)
//                    .shadow(radius: 10)
//                    .position(position)
//                    .position(x: 0, y: 100)
//                    .gesture(gesture)
//                Circle()
//                    .fill(toy.color)
//                    .frame(width: size, height:  size)
//                    .shadow(radius: 10)
//                    .position(position)
//                    .gesture(gesture)
                

// ======================== 기존 코드 텍스트 ======================== //
                
                Text(toy.randomText) // 이것만 남겨둘 경우에는 글자로만 이동이 됨. 근데 답을 어떻게 알지?
                // 빼는 방법은 랜덤 append?
//                    .foregroundColor(toy.color)
                    .position(position)
                    .gesture(gesture)
                    .font(.largeTitle)
                    .buttonStyle(.automatic)

// ======================== 기존 코드 텍스트 ======================== //

            }// End ZStack
        }// End HStack
        
    }
}





struct DraggableToy_Previews: PreviewProvider {
    static var previews: some View {
        // 위 struct DraggableToy: View { 에서 선언된 것들 초기화 시켜주는 작업이 필요해서 아래처럼 진행?

        DraggableToy( // 여기 부분 무슨의미인가?
            toy: Toy.all.first!,
            position: CGPoint(x: 100, y: 100),
            positionTwo: CGPoint(x: 100, y: 200),

            gesture: DragGesture()
        )
    }
}

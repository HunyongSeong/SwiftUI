//
//  SwiftUIView.swift
//  
//
//  Created by David Goggins on 2023/04/13.
//

import SwiftUI

struct BabyToyView: View {
    @StateObject private var viewModel = ToyViewModel()
    
    let gridItems = [ // 아마 그리드에 유연하게 공을 놓기위한 방안이 아닐까?
        GridItem(.flexible()), // 1열
        GridItem(.flexible()), // 2열
        GridItem(.flexible()) // 3열로 만들기.
    ]
    
    var drag: some Gesture{
        DragGesture()
            .onChanged { state in
                viewModel.update(dragPosition: state.location)
            }
            .onEnded { state in
                viewModel.update(dragPosition: state.location)
                // 공을 놓으면 되돌아가게될 위치
                withAnimation { // 애니메이션 효과 / 원래는 그냥 사라지는 것인데 withAnimation{ }하나만으로 자연스럽게 사라지는 것 연출
                    viewModel.confirmDrop()
                }
            }
    }
//    
//    @Binding var currentLine: Line // 라인 만들기 << 우리는 많은 라인을 만들 수 있으므로 어레이 형태로 만들어주기
//
//    @Binding var lines: [Line] // 라인 어레이 만들어주기
//    @Binding var thickness: Double
    
    var body: some View {
        ZStack {
                                                // ForEach(0..<6, id: \.self) { _ in
            LazyVGrid(columns: gridItems, spacing: 100) { // 6개의 공 / spacing: 100 <- 추가시, 간격 넓히기
                ForEach(viewModel.toyContainers, id: \.id) { toy in
                    ToyContainer(
                        toy: toy,
                        viewModel: viewModel
                    )
                }
            }
            
            if let currentToy = viewModel.currentToy {
                DraggableToy( // 빨간공 한개
                    toy: currentToy,
                    position: viewModel.currentPosition, positionTwo: viewModel.currentPosition,
                    gesture: drag
                )
                .opacity(viewModel.draggableToyOpacity)
            }
        }
        .onAppear {
            viewModel.setupGame()
        }
        .alert( // 게임 종료시 alert
            Text("🎉추카포카🎉"),
            isPresented: $viewModel.isGameOver, // 게임 종료시 alert
            actions: { // closure
                Button("다시 도전 ㄱ?") {
                    withAnimation {
                        viewModel.generateNewGame()
                    }
                }
            },
            message: {
                Text("Number of attemps: \(viewModel.attempts)")
            }
        ) // End allert
        .navigationBarHidden(true)
    }
}



struct BabyToyView_Previews: PreviewProvider {
    static var previews: some View {
        BabyToyView()
    }
}

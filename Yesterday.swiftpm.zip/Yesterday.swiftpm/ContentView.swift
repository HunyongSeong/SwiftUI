//
//  ContentsView.swift
//  ColorMatchGame
//
//  Created by David Goggins on 2023/04/18.
//

import SwiftUI

var foodsArray: [String] = []

struct ContentView: View {
    @State var showTextField = ""
    @State var showAlert: Bool = false
    @State var AlertTitle: String  = "AlertTitle"
    @State var countSave: Int = 0
    @State var isActive = true
    var body: some View {
        
        NavigationView { // Start NavigationView
            Text("dismiss")
            VStack {
                Image("imageSquare00001")
                    .resizable()
                    .frame(width: 500, height: 500).padding()
                    .padding()
                Text("Now, would you remember the menu")
                    .font(.system(size: 55, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))
                Text("you had yesterday morning?")
                    .font(.system(size: 55, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))
                TextField("Enter it here", text: $showTextField)
                    .font(.system(size: 55, weight: .semibold, design: .rounded))
                    .background(Color(red: 175, green: 175, blue: 175))
                    .frame(minWidth: 600, idealWidth: 600, maxWidth: 600, minHeight: 200, idealHeight: 200, maxHeight: 200, alignment: .center)
                    .textFieldStyle(.roundedBorder)
                    .navigationBarHidden(true)
                Spacer()
                
                // ====== 디온 ====== //
                VStack {
                    if showTextField.isEmpty{
                        Text("SAVE")
                            .padding()
                            .frame(maxWidth:600)
                            .background(Color.gray)
                            .cornerRadius(10)
                            .font(.system(size: 50, weight: .semibold, design: .rounded))
                            .foregroundColor(.white)
                    }
                    else{
                        NavigationLink(destination: ContentViewTwo()){
                            Text("SAVE")
                                .padding()
                                .frame(maxWidth: 600)
                                .background(Color(red: 254 / 255, green: 153 / 255, blue: 233 / 255))
                                .cornerRadius(10)
                                .font(.system(size: 50, weight: .semibold, design: .rounded))
                                .foregroundColor(.white)
                        }
                        .simultaneousGesture(TapGesture().onEnded( {
                            saveButton()
                        }))
                    }
                }
                
                Spacer()
                
                ForEach(foodsArray, id: \.self) { item in
                    Text(item)
                }
                Spacer()
            }
            .padding()
            .alert(isPresented: $showAlert, content: getAlert)
        } // End NavigationView
        .navigationBarHidden(true)
    }
    
    func getAlert() -> Alert {
        Alert(title: Text(AlertTitle))
    }
    
    func saveButton() {
        saveItem()
    }
    
    func saveItem() { // foodsArray에 showTextField를 넣겠다.
        foodsArray.append(showTextField)
        //        showTextField = "" // 그리고 다시 showTextField 초기화 -> 입력창 초기화 진행
        print(foodsArray)
    }
}

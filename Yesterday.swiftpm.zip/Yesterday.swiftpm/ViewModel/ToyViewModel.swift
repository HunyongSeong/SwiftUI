//
//  File.swift
//  
//
//  Created by David Goggins on 2023/04/13.
//

import SwiftUI

// key representing와 container id, CGRect를 저장하기 위한 딕셔너리
class ToyViewModel: ObservableObject {
    //MARK: - Gesture Properties
    @Published var currentToy: Toy?
    @Published var currentPosition = initialPosition
    @Published var currentPositionTwo = initialPosition // << ADD ✅
    
    //@Published <- 빨간 공의 움직임을 계속 화면에 업데이트
    
    @Published var highlightedId: Int? // 공을 드래그해서 해당 위치에 끌어놓을 때 하이라이트
    @Published var draggableToyOpacity: CGFloat = 1.0
    @Published var isGameOver = false
    private(set) var attempts = 0
    
    // MARK: - Coordinates
    private static let initialPosition = CGPoint(
        x: UIScreen.main.bounds.midX,
        y: UIScreen.main.bounds.midY + (UIScreen.main.bounds.midY / 10) * 6
        
        //        y: UIScreen.main.bounds.midY - 100
        
    )
    
    private static let initialPositionTwo = CGPoint( // << ADD
        x: UIScreen.main.bounds.midX,
        y: UIScreen.main.bounds.midY - UIScreen.main.bounds.midY / 1.2 + 200
        
        //        y: UIScreen.main.bounds.midY - 100
        
    )
    
    private var frames: [Int: CGRect] = [:]
    
    //MARK: - Objects in the screen
    // 랜덤으로 3개의 공 가져오는 코드
    private var toys = Array(Toy.all.shuffled().prefix(upTo: 3))
    var toyContainers = Toy.all.shuffled()
    
    // MARK: - Game lifecycle
    func setupGame() {
        currentToy = toys.popLast()
    }
    
    func nextRound() { // 배열에서 새로운 공을 확인하는것. 부합하지 않다면 게임 종료
        currentToy = toys.popLast()
        
        if currentToy == nil {
            gameOver()
        } else {
            prepareObjects()
        }
    }
    
    func gameOver() { // 게임 오버
        isGameOver = true
    }
    
    func prepareObjects() { // 샐로운 공 준비 / 투명도 다시 복원하는 로직 잊으면 안된다.
        withAnimation {
            toyContainers.shuffle()
            //            resetPosition()
            //            draggableToyOpacity = 1.0 // 애니메이션 부분제거를 위해 아래처럼 진행
        }
        withAnimation(.none) {
            resetPosition() // 포지션 리셋시에는 애니메이션 없애기
            withAnimation { // 애니메이션
                draggableToyOpacity = 1.0 // <- 이부분은 그냥 위에 둬도 될듯한데?
            }
        }
        
    }
    
    //MARK: - 공 개수 -1 -> prefix(upTo: 5)
    func generateNewGame() { // 게임 종료 후 할것
        toys = Array(Toy.all.shuffled().prefix(upTo: 3)) // 게임종료시 다시 3개 랜덤 공 배열 생성
        attempts = 0 // 시도 횟수 0으로 초기화
        nextRound() // 다음 라운드 실행
    }
    
    // MARK: - Updates in the screen
    func update(frame: CGRect, for id: Int) {
        frames[id] = frame
    }
    
    func update(dragPosition: CGPoint) {
        currentPosition = dragPosition
        for(id, frame) in frames where frame.contains(dragPosition) {
            highlightedId = id
            return
        }
        
        highlightedId = nil
        
    }
    
    func confirmDrop() {
        //resetPosition() <- Erase!!
        defer { highlightedId = nil }
        
        // 하이라이트 된 상태, 즉 인접한 상태일 때는 포지션을 리셋하지 않고, 외부에 드래그 하면 포지션이 리셋
        guard let highlightedId = highlightedId else {
            resetPosition()
            return
        }
        
        if highlightedId == currentToy?.id {
            guard let frame = frames[highlightedId] else {
                return
            }
            currentPosition = CGPoint(x: frame.midX + 500, y: frame.midY + 500)
            currentPositionTwo = CGPoint(x: frame.midX, y: frame.midY + 100)
            draggableToyOpacity = 0
            nextRound()
        } else {
            resetPosition()
        }
        attempts += 1
    }
    
    func resetPosition() {
        currentPosition = ToyViewModel.initialPosition
    }
    
    func isHighlighted(id: Int) -> Bool {
        highlightedId == id
    }
}

//
//  Toy.swift
//  ColorMatchGame
//
//  Created by David Goggins on 2023/04/13.
//

import SwiftUI

struct Toy {
    let id: Int
    let color: Color
    //    var rectImage: Image
    var rectImagename: String
    
    var circleText: String
    var randomText: String
}

extension Toy { // 값을 미리 만들어 주기 위해 확장. 생성자관련?
    static let all = [
        // 원본
        //        Toy(id:1, color: .red, circleText: "Breakfast"),
        //        Toy(id:2, color: .blue, circleText: "Lunch"),
        //        Toy(id:3, color: .green, circleText: "Dinner"),
        //        Toy(id:4, color: .black, circleText: "Breakfast2"),
        //        Toy(id:5, color: .orange, circleText: "Lunch2"),
        //        Toy(id:6, color: .purple, circleText: "Dinner2")
        
        //         //수정본
        //        Toy(id:1, color: .yellow, rectImage: Image("imageSquare00001"), circleText: "Breakfast", randomText: foodsArray[0]),
        //        Toy(id:2, color: .orange, rectImage: Image("imageSquare00001"), circleText: "Lunch", randomText: foodsArray[1]),
        //        Toy(id:3, color: .purple, rectImage: Image("imageSquare00001"), circleText: "Dinner", randomText: foodsArray[2])
        
        
        //수정본 최종
        Toy(id:1, color: .yellow, rectImagename: "imageSquare00001", circleText: "Breakfast", randomText: foodsArray[0]),
        Toy(id:2, color: .orange, rectImagename: "imageSquare00002", circleText: "Lunch", randomText: foodsArray[1]),
        Toy(id:3, color: .purple, rectImagename: "imageSquare00003", circleText: "Dinner", randomText: foodsArray[2])
        
        //        //실험용
        //                Toy(id:1, color: .yellow, circleText: "Breakfast", randomText: "아"),
        //                Toy(id:2, color: .orange, circleText: "Lunch", randomText: "아2"),
        //                Toy(id:3, color: .purple, circleText: "Dinner", randomText: "아3")
        
        
    ]
    
}

//
//  Story01.swift
//  ColorMatchGame
//
//  Created by David Goggins on 2023/04/20.
//

import SwiftUI

struct Story01: View {
    var body: some View {
        NavigationView {
            Text("Let's fun")
                .font(.system(size: 30, weight: .semibold, design: .rounded))
            
            ZStack {
                Color(red: 255 / 255, green: 242 / 255, blue: 125 / 255).ignoresSafeArea()
                VStack {
                    
                    Text("What did you eat yesterday?")
                        .font(.system(size: 55, weight: .semibold, design: .rounded))
                        .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))
                        .offset(y: -100)
                    //                                        .opacity(0)
                    
                    Image("imageSquare0000")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 800, height: 800, alignment: .center)
                        .offset(y: -100)
                    
                    //                    Text("Can you remember immediately what you ate for lunch yesterday?")
                    //                        .font(.system(size: 40, weight: .semibold, design: .rounded))
                    //                        .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))
                    //                        .padding(30)
                    //                        .background(Color.white)
                    //                        .border(.white, width: 3) // border 설정 (Rectangle일 때)
                    //                        .overlay( // 뷰를 겹치게 하여 border 설정, 라운드 처리를 할 경우 overlay를 통해 border 처리를 해주어야 한다.
                    //                            RoundedRectangle(cornerRadius: 20)
                    //                                .stroke(Color.white, lineWidth: 20)
                    //                        )
                    //                        .offset(y: -100)
                    
                    NavigationLink(destination: Story02()){
                        Text("START")
                            .frame(width: 300, height: 100)
                            .background(Color.white)
                            .cornerRadius(50)
                        //                            .font(.largeTitle)
                            .font(.system(size: 50, weight: .semibold, design: .rounded))
                            .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))
                        //                            .offset(y:-50)
                        
                    }// EndNavigationLink
                    
                }
            }
        }
    }
}

struct Story01_Previews: PreviewProvider {
    static var previews: some View {
        Story01()
    }
}

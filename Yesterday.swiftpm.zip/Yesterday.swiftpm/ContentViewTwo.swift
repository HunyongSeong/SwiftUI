//
//  ContentsView.swift
//  ColorMatchGame
//
//  Created by David Goggins on 2023/04/18.
//

import SwiftUI

struct ContentViewTwo: View {
    @State var showTextField = ""
    @State var showAlert: Bool = false
    @State var AlertTitle: String  = "AlertTitle"
    @State var countSave: Int = 0
    var body: some View {
        Text("dismiss")
        VStack {
            Image("imageSquare00002")
                .resizable()
                .frame(width: 500, height: 500).padding()
                .padding()
            Text("That's amazing!")
                .font(.system(size: 55, weight: .semibold, design: .rounded))
                .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))
            Text("Remember the yesterday lunch menu, too!")
                .font(.system(size: 55, weight: .semibold, design: .rounded))
                .foregroundColor(Color(red: 58 / 255, green: 8 / 255, blue: 69 / 255))
            TextField("Enter it here", text: $showTextField)
                .font(.system(size: 55, weight: .semibold, design: .rounded))
                .background(Color(red: 175, green: 175, blue: 175))
                .frame(minWidth: 600, idealWidth: 600, maxWidth: 600, minHeight: 200, idealHeight: 200, maxHeight: 200, alignment: .center)
                .textFieldStyle(.roundedBorder).padding()
            
            Spacer()
            // ====== 디온 ====== //
            VStack {
                if showTextField.isEmpty{
                    Text("SAVE")
                        .padding()
                        .frame(maxWidth:600)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .font(.system(size: 50, weight: .semibold, design: .rounded))
                        .foregroundColor(.white)
                }
                else{
                    NavigationLink(destination: ContentViewThree()){
                        Text("SAVE")
                            .padding()
                            .frame(maxWidth: 600)
                            .background(Color(red: 254 / 255, green: 153 / 255, blue: 233 / 255))
                            .cornerRadius(10)
                            .font(.system(size: 50, weight: .semibold, design: .rounded))
                            .foregroundColor(.white)
                    }
                    .simultaneousGesture(TapGesture().onEnded( {
                        saveButton()
                    }))
                }
            }
            Spacer()
        }
        .padding()
        .alert(isPresented: $showAlert, content: getAlert)
        .navigationBarHidden(true)
    }
    func getAlert() -> Alert {
        Alert(title: Text(AlertTitle))
    }
    func saveButton() {
        if   textIsAppropriate() {
            saveItem()
        }
    }
    func textIsAppropriate() -> Bool {
        if showTextField.count < 1 {
            AlertTitle = "한글자 이상 입력해주세요."
            showAlert.toggle()
            return false
        }
        return true
    }
    func saveItem() { // foodsArray에 showTextField를 넣겠다.
        foodsArray.append(showTextField)
        //        showTextField = "" // 그리고 다시 showTextField 초기화 -> 입력창 초기화 진행
        print(foodsArray)
        
    }
}

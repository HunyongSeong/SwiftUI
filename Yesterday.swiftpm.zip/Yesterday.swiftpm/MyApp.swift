import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
//            BabyToyView() // 바로 게임시작
//            ContentView() // 빌드업
            Story01() // 스토리보드 부터 실행
        }
    }
}

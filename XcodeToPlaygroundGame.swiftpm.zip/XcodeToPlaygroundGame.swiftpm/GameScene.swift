import SpriteKit
import GameplayKit // <- 기존강의에서 있었음

class GameScene: SKScene {
    
    let gridMap = SKNode()

    override func didMove(to view: SKView) {
        setupMap()
    }
    
    func setupMap() {//(2)
        gridMap.position = CGPoint(x: size.width / 2, y: size.height / 2)
        self.addChild(gridMap)
        
        //기초 정보 초기화
        // SKTile을 사용하겠다고 선언 (파일에서 불러오는 것 이기 때문에 가드렛으로 방어적인 코드 )
        guard let tileSet = SKTileSet(named: "Sample Grid Tile Set") else { return }
        let tileSize = CGSize(width: 128, height: 128)
        let colum = 16 // 세로 축 화면 크기
        let rows = 16 // 가로 축 화면 크기
        
        let sandTiles = tileSet.tileGroups.first { $0.name == "Sand" } // 네임이 샌드면 여기에 넣는다
//        let stoneTiles = tileSet.tileGroups.first { $0.name == "Cobblestone" }
//        let waterTiles = tileSet.tileGroups.first { $0.name == "Water" }
//
        // 바닥 생성: SK에서 타일 채우고 Z포지션 1로 하고 바닥부분을 샌드타일로 모두 채우겠다.
        let bottomLayer = SKTileMapNode(tileSet: tileSet, columns: colum, rows: rows, tileSize: tileSize)
        bottomLayer.fill(with: sandTiles) //fill로 샌드타일로 다 채울 수 있음
        bottomLayer.zPosition = 1
//        bottomLayer.lightingBitMask = 1 // 바닥에 라이팅비트마스크 주기(빛)
        gridMap.addChild(bottomLayer)
    }
}


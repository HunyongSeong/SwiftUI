import SwiftUI
import SpriteKit
//import SceneKit
import GameplayKit // <- 그냥 추가해봄


struct ContentView: View {
    
//        @State var currentScene: SKScene = GameScene(size:
//            CGSize(width: 1024, height: 768))
    
    
    // === 여기부터 유튜브에서 보고 작성한 코드 === //
    let screenWidth = UIScreen.main.bounds.width
    let screenHeight = UIScreen.main.bounds.height


    //define a scene
    var scene: SKScene {

//        if let view = self.scene as! SKView? {
        let scene = GameScene(size: CGSize(width: 1536, height: 2048))
            scene.scaleMode = .aspectFit
//            view.presentScene(scene)
            scene.backgroundColor = .white

//            view.ignoresSiblingOrder = true
//            view.showsFPS = true
//            view.showsNodeCount = true



            return scene
//        } // End: if let view
    }
    
    
    var body: some View {
        VStack{
            SpriteView(scene: scene)
                .frame(width: screenWidth, height: screenHeight)
                .edgesIgnoringSafeArea(.all)
        }
    }
    
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

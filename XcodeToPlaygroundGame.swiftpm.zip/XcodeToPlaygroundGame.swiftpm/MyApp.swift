import SwiftUI
import GameplayKit // <- 그냥 추가해봄
import SpriteKit// <- 그냥 추가해봄

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

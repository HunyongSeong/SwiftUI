//
//  SwiftUIView.swift
//  
//
//  Created by David Goggins on 2023/04/13.
//

import SwiftUI

struct DraggableToy<Draggable: Gesture>: View {
    //<Draggable: Gesture> / Protocol
    let toy: Toy
    private let size: CGFloat = 100
    let position: CGPoint
    let gesture: Draggable
    
    var body: some View {
        Circle()
            .fill(toy.color)
            .frame(width: size, height:  size)
            .shadow(radius: 10)
            .position(position)
            .gesture(gesture)
    }
}

struct DraggableToy_Previews: PreviewProvider {
    static var previews: some View {
        // 위 struct DraggableToy: View { 에서 선언된 것들 초기화 시켜주는 작업이 필요해서 아래처럼 진행?
        
        DraggableToy( // 여기 부분 무슨의미인가?
            toy: Toy.all.first!,
            position: CGPoint(x: 100, y: 100),
            gesture: DragGesture()
        )
    }
}

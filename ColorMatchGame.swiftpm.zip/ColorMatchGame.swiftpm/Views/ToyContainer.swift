//
//  SwiftUIView.swift
//  
//
//  Created by David Goggins on 2023/04/13.
//

import SwiftUI

struct ToyContainer: View {
    let toy: Toy
    @ObservedObject var viewModel: ToyViewModel
    private let regularSize: CGFloat = 100
    private let highlightedSize: CGFloat = 130
    
    var body: some View {
        ZStack{
            Circle()
                .fill(toy.color)
                .frame(width: regularSize, height: regularSize)
                .overlay {
                    GeometryReader { proxy -> Color in
                        viewModel.update(
                            frame: proxy.frame(in: .global),
                            for: toy.id
                        )
                        
                        return Color.clear
                    }
                }
            if viewModel.isHighlighted(id: toy.id){
                Circle()
                    .fill(toy.color)
                    .opacity(0.5)
                    .frame(width: highlightedSize, height: highlightedSize)
            }
        }
        .frame(width: highlightedSize, height: highlightedSize)
        // 해당 코드로 인해서 하이라이트시에도 다른 공들의 위치가 변하지 않음
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        ToyContainer(toy: Toy.all.first!, viewModel: ToyViewModel())
    }
}
